import matplotlib.pyplot as plt
import numpy as np 

##plot of the Epiderm/cortex/endoderm/ from the csv
path =  './'
fileName = path+'analysis/root/tableVolume.csv'

f = open(fileName, 'r')
data= f.readlines()
f.close()


for eachLine in range(len(data)):
	data[eachLine] = data[eachLine][:-1].split(',')
	if eachLine != 0 :
		for eachCol in range(len(data[eachLine])):
			if data[eachLine][eachCol] != '':
				data[eachLine][eachCol] = float(data[eachLine][eachCol])
			else :
				data[eachLine][eachCol] = np.nan
	
data = np.array(data[2:])


fig, ax = plt.subplots()
distri = [[],[],[]]
vals = []
medians = []
colors = [(128/255,24/255,0/255),(94/255,173/255,39/255),(17/255,109/255,237/255)]
colorsMark = [(255/255,10/255,10/255),(10/255,255/255,10/255),(10/255,10/255,255/255)]
lwBox=2.5
side=[-0.15,0.15,-0.25]
for eachCase in range(5*3):
	if eachCase%5 == 0:
		medians.append([])
	vals.append(data[~(np.isnan(data[:,eachCase])),eachCase])
	medians[-1].append(np.nanmedian(vals[-1]))

	if (eachCase+1)%5 == 0 :
		c = colors[int(eachCase/5)]
		distri[int(eachCase/5)].append(vals[eachCase-4:eachCase+1])
		box = plt.boxplot(vals[eachCase-4:eachCase+1],
            boxprops=dict(facecolor=c,color='k',linewidth=lwBox),
            capprops=dict(color='k',linewidth=lwBox),
            whiskerprops=dict(color='k',linewidth=lwBox),
            flierprops=dict(markerfacecolor=c, markeredgecolor='k', markersize=12,markeredgewidth=lwBox),
            medianprops=dict(color='k',linewidth=2),widths=0.2,patch_artist=True, positions = [ pos+side[int(eachCase/5)] for pos in range(1,6)])
		for iw in range(int(len(box['whiskers'])/2)):
				box['whiskers'][iw*2].set_data(((box['whiskers'][iw*2].get_data()[0][0]-np.sign(side[int(eachCase/5)])*0.1,box['whiskers'][iw*2].get_data()[0][1]-np.sign(side[int(eachCase/5)])*0.1), box['whiskers'][iw*2].get_data()[1]))
				box['whiskers'][iw*2+1].set_data(((box['whiskers'][iw*2+1].get_data()[0][0]-np.sign(side[int(eachCase/5)])*0.1,box['whiskers'][iw*2+1].get_data()[0][1]-np.sign(side[int(eachCase/5)])*0.1), box['whiskers'][iw*2+1].get_data()[1]))
		for cap in box['caps']:
			cap.set_xdata(cap.get_xdata() + np.array([-.05,.05]))
		plt.plot(range(1,6),medians[-1], 'kD--',linewidth=lwBox, markersize=8,markerfacecolor = colorsMark[int(eachCase/5)],markeredgewidth=0,zorder=10+int(eachCase/5), solid_capstyle='round',dash_capstyle='round',dash_joinstyle='round') 

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_visible(False)
ax.spines['left'].set_visible(False)
ax.vlines(0,ymin=0,ymax=4000,lw=4,color='k')
ax.hlines(0,xmin=1,xmax=5,lw=4,color='k')
plt.setp(ax.spines.values(), lw=2)
ax.set_xticks(range(1,6))
ax.set_xticklabels([ 't'+ str(i) for i in range(1,6)])
ax.xaxis.set_tick_params(labelsize=18,width=2)
ax.yaxis.set_tick_params(labelsize=18,width=2)

for tick in ax.get_xticklabels():
    tick.set_fontweight('bold')
for tick in ax.get_yticklabels():
    tick.set_fontweight('bold')

plt.xlim(xmin=0)
plt.ylim(ymin=0)
ax.set_xlabel('position along the root', fontsize=18, weight='bold')
ax.set_ylabel('Volume ($µm^3$)', fontsize=18, weight='bold')
plt.show()

#comparison
import scipy.stats as st
test = []
for i in xrange(5):
	print(' ---test normalite '+str(i)+' time')
	print(st.shapiro(distri[0][0][i]))
	print(st.shapiro(distri[1][0][i]))
	print(st.shapiro(distri[2][0][i]))
	print('--- comparison ---')
	print(st.ks_2samp(distri[0][0][i],distri[1][0][i]))
	print(st.ks_2samp(distri[1][0][i],distri[2][0][i]))
	print(st.ks_2samp(distri[2][0][i],distri[0][0][i]))	

