import numpy as np
import matplotlib.pyplot as plt

path = './analysis/embryo/'
x = np.load(path+'xPlotVolume.npy')
ye = np.load(path+'yEPlotVolume.npy')
yi = np.load(path+'yIPlotVolume.npy')

yeSEM = np.load(path+'yESEMPlotVolume.npy')
yiSEM = np.load(path+'yISEMPlotVolume.npy')

iStop = np.squeeze(np.argwhere(np.isnan(ye)))
print(iStop)
x = np.delete(x, iStop)
ye = np.delete(ye, iStop)
yi = np.delete(yi, iStop)

plt.clf()
plt.errorbar(x,ye, yerr=yeSEM,color='gray',label='protoderm',ls = '--', marker= 'o')
plt.errorbar(x,yi, yerr=yiSEM,color='k',label='intern', marker = 'o')
plt.ylabel('mean cell volume ($\mu m^{3}$)', fontsize=16)
plt.xlabel('number of cells in the embryo', fontsize=14)
plt.ylim(ymin=0)
plt.xlim(xmin=x[0]-2,xmax = x[-1]+2)
plt.legend()
plt.savefig(path+'graphVolume.pdf',bbox_inches='tight')


yEVT = np.load(path+'yEVTPlotVolume.npy')
yIVT = np.load(path+'yIVTPlotVolume.npy')
plt.clf()
fig, ax = plt.subplots()
ax.plot(x,yEVT,color='gray',label='protoderm',ls = '--', marker= 'o')
ax.plot(x,yIVT, color='k',label='intern', marker= 'o')
plt.ylabel('volume ($\mu m^{3}$)', fontsize=16)
plt.xlabel('number of cells in the embryo', fontsize=14)
plt.ylim(ymin=0)
plt.xlim(xmin=x[0],xmax = x[-1])
plt.legend()
ax.ticklabel_format(axis='y',style='sci', scilimits=(0,0))
plt.savefig(path+'graphVolumeTotal.pdf',bbox_inches='tight')

