import numpy as np
import matplotlib.pyplot as plt

path = './analysis/embryo/'
x = np.load(path+'xPlotVolume.npy')
ye = np.load(path+'yEPlotVolume.npy')
yi = np.load(path+'yIPlotVolume.npy')

yeMin = np.load(path+'yEminPlotVolume.npy')
yiMin = np.load(path+'yIminPlotVolume.npy')

yeMax = np.load(path+'yEmaxPlotVolume.npy')
yiMax = np.load(path+'yImaxPlotVolume.npy')

iStop = np.squeeze(np.argwhere(np.isnan(ye)))
print(iStop)
x = np.delete(x, iStop)
ye = np.delete(ye, iStop)
yi = np.delete(yi, iStop)

plt.clf()
plt.errorbar(x,ye, yerr=np.concatenate(([yeMin],[yeMax]),axis=0),color='gray',label='protoderm',ls = '--', marker= 'o')
plt.errorbar(x,yi, yerr=np.concatenate(([yiMin],[yiMax]),axis=0),color='k',label='intern', marker = 'o')
plt.ylabel('mean cell volume ($\mu m^{3}$)')
plt.xlabel('number of cells in the embryo')
plt.ylim(ymin=0)
plt.xlim(xmin=x[0]-2,xmax = x[-1]+2)
plt.legend()
plt.savefig(path+'graphVolume.pdf')


yEVT = np.load(path+'yEVTPlotVolume.npy')
yIVT = np.load(path+'yIVTPlotVolume.npy')
plt.clf()
plt.plot(x,yEVT,color='gray',label='protoderm',ls = '--', marker= 'o')
plt.plot(x,yIVT, color='k',label='intern', marker= 'o')
plt.ylabel('volume ($\mu m^{3}$)')
plt.xlabel('number of cells in the embryo')
plt.ylim(ymin=0)
plt.xlim(xmin=x[0],xmax = x[-1])
plt.legend()
plt.savefig(path+'graphVolumeTotal.pdf')

