###  trichoblaste plot from treeV and the tif to extract the volumes
import glob
import numpy as np
from skimage import io
import matplotlib.pyplot as plt

def getleaves(tree, father):

# Determine leaves of a summit of label 'father'
#
#inputs :
#           tree: array of mother cells
#           father : label of the mother cell
#
# outputs :
#           leaves : list of cells

	e= [father]
	leaves=[]
	while e != [] :
		p1=[]
		for i in range(len(e)):
			flag = 0
			for label in range(len(tree)):
				if tree[label] == e[i]:
					p1.append(label +1)
					flag = flag +1
					
			if flag == 0 :
				leaves.append(e[i])
		e=p1
	return leaves
	
def findRoot(tree):
# find the origine of the tree
#
#inputs :
#           tree: array of mother cells
#
# outputs :
#           root : label of the mother cell
		root=0
		for i in range(len(tree)) : 
			if (tree[i] == 0) and ((i+1) in tree) :
				root = i+1
		if root==0:
			print('no root')
		return root

path =  './'
segFile = path+ "examples/root/Reslice of Reslice-catchment-basins.tif" 

seg = io.imread(segFile).astype(np.int64)

treeTissuesFile = path+ "examples/root/Reslice of Reslice-catchment-basins.treeV"

## extract the tree from the treeV (main one)
f = open(treeTissuesFile,'r')
data= f.readlines()
f.close()
treeMain = data[0][:-1].split('	')
treeMain = list(map(int,treeMain))
tags = data[1][:-1].split('	')

## extract the trees from the treeV files (trichoblaste ones)
trichoblastesFiles = glob.glob(path+ "examples/root/Epi*.treeV")
trichoblastesCellsAll = []
for eachF in range(len(trichoblastesFiles)):
	f = open(glob.glob(path+ "examples/root/Epi"+str(eachF+1)+"*.treeV")[0], 'r')
	data= f.readlines()
	f.close()

	tree = data[0][:-2].split('\t')
	tree = list(map(int,tree))
	trichoblastesCells = getleaves(tree, findRoot(tree) )
	trichoblastesCellsAll.append(trichoblastesCells)

#extract the cell volumes
volumesTriAll = []
volumesNTriAll = []
for eachTime in range(5):
	rootTissue = 0
	for each in range(len(tags)):
		if tags[each] == ('Epi'+str(eachTime+1)):
			rootTissue = each+1
	if rootTissue==0:
		print('error ' +('Epi'+str(eachTime+1))+' not found')
	epiCells = getleaves(treeMain, rootTissue )
	nonTriCells = [ i for i in epiCells if not(i in trichoblastesCellsAll[eachTime])]
	
	volumesTri = []
	for triCell in trichoblastesCellsAll[eachTime]:
		volumesTri.append(len(np.argwhere(seg == triCell))*0.6918883*0.6918883*0.4)
	volumesNTri = []
	for ntriCell in nonTriCells:
		volumesNTri.append(len(np.argwhere(seg == ntriCell))*0.6918883*0.6918883*0.4)
		
	volumesTriAll.append(volumesTri)
	volumesNTriAll.append(volumesNTri)

## plot figure 6
fig, ax = plt.subplots()
colors = [(0,123/255,250./255),(0,44/255,98./255)]

c = colors[0]
medians = []
for eachCase in range(5):
	medians.append(np.nanmedian(volumesTriAll[eachCase]))
	plt.boxplot(volumesTriAll[eachCase],patch_artist=True,
          #boxprops=dict(facecolor=c, color=c),
          capprops=dict(color='k'),
          whiskerprops=dict(color='k'),
          boxprops = dict(color='k', facecolor=c),
          flierprops=dict(markerfacecolor=c, markeredgecolor='k'),
          medianprops=dict(color='k'),positions = [eachCase+1-0.1])

plt.plot(range(1,6),medians,color= c,linestyle='--')
			
c = colors[1]
medians = []
for eachCase in range(5):
	medians.append(np.nanmedian(volumesNTriAll[eachCase]))
	plt.boxplot(volumesNTriAll[eachCase],patch_artist=True,
          #boxprops=dict(facecolor=c, color=c),
          capprops=dict(color='k'),
          whiskerprops=dict(color='k'),
          boxprops = dict(color='k', facecolor=c),
          flierprops=dict(markerfacecolor=c, markeredgecolor='k'),
          medianprops=dict(color='k'),positions = [eachCase+1+0.1])


	
plt.plot(range(1,6),medians,color= c,linestyle='--')

plt.xticks([1,2,3,4,5])
plt.xlim(xmin= 0.5,xmax = 5+0.5)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_visible(False)
ax.spines['left'].set_visible(False)
ax.vlines(0,ymin=500,ymax=2500,lw=4,color='k')
ax.hlines(2650,xmin=1,xmax=5,lw=4,color='k')
plt.setp(ax.spines.values(), lw=2)
ax.set_xticks(range(1,6))
ax.set_xticklabels([ 'P'+ str(i) for i in range(1,6)])
ax.xaxis.set_tick_params(top=True, labeltop=True, bottom=False, labelbottom=False,labelsize=12,width=2)
ax.yaxis.set_tick_params(labelsize=12,width=2)

#for tick in ax.get_xticklabels():
#    tick.set_fontweight('bold')
#for tick in ax.get_yticklabels():
#    tick.set_fontweight('bold')

plt.xlim(xmin=0)
plt.ylim(ymin=0,ymax= 2650)
#ax.set_xlabel('position along the root', fontsize=18, weight='bold')
ax.set_ylabel('Volume ($µm^3$)', fontsize=18, weight='bold')
plt.show()

#comparison
import scipy.stats as st
st.ks_2samp(np.concatenate(volumesNTriAll),np.concatenate(volumesTriAll), alternative = 'greater')

